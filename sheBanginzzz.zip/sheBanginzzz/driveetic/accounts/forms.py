
from urllib import request
from django.contrib.auth.models import User
from django.contrib.auth.views import LoginView
from django.shortcuts import redirect

from accounts.views import Login



class login_view(LoginView):

    def get_redirect_url(self) -> str:
        self.request.user.is_staff
        if User is not None:
            Login(request, User)
            if User.is_staff:
                return redirect('admin/')
            else:
                return redirect('updownfunks:index')
        return super().get_redirect_url()