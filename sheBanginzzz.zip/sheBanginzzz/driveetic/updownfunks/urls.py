from django.urls import path
from . import views


urlpatterns = [
    path('', views.index_view, name='index'), 
    path('cdashboard/', views.dashboard_view, name='cdashboard'),
    path('file/upload/', views.file_upload_view, name='file_upload'),
    path('file/<pk>/download/', views.file_download_view, name='file_download'),
    path('file/<pk>/delete/', views.file_delete_view, name='file_delete'),
]