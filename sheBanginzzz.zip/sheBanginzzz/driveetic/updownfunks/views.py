import cachecontrol
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from.models import File
from updownfunks.forms import FileUploadForm

from django.views.decorators.http import require_GET
@require_GET
def favicon(request):
    return HttpResponse(
        '<svg href="/workspaces/sheBanginzzz/driveetic/static/icons8-star-16.png" viewBox="0 0 100 100">'
        + '<text y=".9em" font-size="90">👾</text>'
        + "</svg>",
        content_type="image/svg+xml",
    )





def index_view(request):
    return render(request, 'updownfunks/index.html')


@login_required
def dashboard_view(request):
    files = File.objects.filter(uploaded_by=request.user)
    return render(request, 'cdashboard.html', {'files': files})

@login_required
def file_upload_view(request):
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            file = form.save(commit=False)
            file.uploaded_by = request.user
            file.save()
            return redirect('updownfunks:cdashboard')
    else:
        form = FileUploadForm()
    return render(request, 'file_upload.html', {'form': form})

@login_required
def file_download_view(request, pk):
    file = File.objects.get(pk=pk)
    if file.uploaded_by == request.user:
        return redirect(file.file.url)
    else:
        return redirect('updownfunks:cdashboard')

@login_required
def file_delete_view(request, pk):
    file = File.objects.get(pk=pk)
    if file.uploaded_by == request.user:
        file.delete()
        return redirect('updownfunks:cdashboard')
    else:
        return redirect('updownfunks:cdashboard')