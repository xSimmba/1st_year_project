from django.shortcuts import redirect, render
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from.models import File

@login_required
@user_passes_test(lambda u: u.is_staff)
def dashboard_view(request):
    files = File.objects.all()
    return render(request, 'staff/staff_dashboard.htm', {'files': files})

@login_required
@user_passes_test(lambda u: u.is_staff)
def file_detail_view(request, pk):
    file = File.objects.get(pk=pk)
    return render(request, 'staff/file_detail.html', {'file': file})

@login_required
@user_passes_test(lambda u: u.is_staff)
def file_delete_view(request, pk):
    file = File.objects.get(pk=pk)
    file.delete()
    return redirect('staff:staff_dashboard.html')