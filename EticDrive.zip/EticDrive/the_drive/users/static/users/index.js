import axios from 'axios';

const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');

loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    try {
        const response = await axios.post('/api/login/', { username, password });
        if (response.data.message === 'Logged in successfully') {
            // Login successful, redirect to home page
            window.location.href = '/';
        } else {
            alert('Invalid username or password');
        }
    } catch (error) {
        console.error(error);
    }
});

registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const user_type = document.getElementById('user_type').value;
    try {
        const response = await axios.post('/api/register/', { username, email, password, user_type });
        if (response.data.message === 'Registered successfully') {
            // Register successful, redirect to login page
            window.location.href = '/login/';
        } else {
            alert('Registration failed');
        }
    } catch (error) {
        console.error(error);
    }
});