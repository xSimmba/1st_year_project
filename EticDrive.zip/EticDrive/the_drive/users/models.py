from django.contrib.auth.models import AbstractUser, UserManager

from django.db import models

class CustomUser(AbstractUser):
    USER_TYPES = (
        ('staff', 'Staff', 'is_staff'),
        ('client', 'Client', 'is_client'),
        
    )
    
    is_staff = models.BooleanField(default=False)
    is_client = models.BooleanField(default=False)

    user_type = models.CharField(max_length=10, choices=USER_TYPES, default='client')

class CustomUserManager(UserManager):
    def create_staffuser(self, username, email, password):
        user = self.create_user(username, email, password)
        user.user_type = 'staff'
        user.is_staff = True
        user.save()
        return user

    def create_clientuser(self, username, email, password):
        user = self.create_user(username, email, password)
        user.user_type = 'client'
        user.save()
        return user