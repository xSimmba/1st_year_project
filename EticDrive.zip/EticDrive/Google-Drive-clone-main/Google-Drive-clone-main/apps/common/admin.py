from django.contrib import admin

from .models import StarredItem

admin.site.register(StarredItem)
