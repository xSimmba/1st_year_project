# Google Drive Clone
Google Drive clone built with django rest framework

# Features
A list of  features that this clone has.

- User Registration and Login
- File Upload
- Download Files
- Star/Unstar files
- Folders for file organization
- Share files to other users
- View Shared Files
- File Commenting
- Search whole drive
- Search for folder in drive
- Folder content search
- Shared file status with multiple users access

# Features to be built
- Notifications
- User Logout
- Google autentication 
