from django.urls import path
from. import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('', views.index, name='index'),
    path('create_folder/', views.create_folder, name='create_folder'),
    path('create_subfolder/<int:folder_id>/', views.create_subfolder, name='create_subfolder'),
    path('upload_file/', views.upload_file, name='upload_file'),
]