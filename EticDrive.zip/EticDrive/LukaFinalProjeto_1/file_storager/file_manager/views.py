from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from.models import User, File, Folder, Subfolder

def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        user = User.objects.create_user(username, email, password)
        login(request, user)
        return redirect('index')
    return render(request, 'register.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('index')
    return render(request, 'login.html')

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def index(request):
    files = File.objects.filter(user=request.user)
    folders = Folder.objects.filter(user=request.user)
    return render(request, 'index.html', {'files': files, 'folders': folders})

@login_required
def create_folder(request):
    if request.method == 'POST':
        name = request.POST['name']
        folder = Folder.objects.create(name=name, user=request.user)
        return redirect('index')
    return render(request, 'create_folder.html')

@login_required
def create_subfolder(request, folder_id):
    folder = Folder.objects.get(id=folder_id)
    if request.method == 'POST':
        name = request.POST['name']
        subfolder = Subfolder.objects.create(name=name, folder=folder, user=request.user)
        return redirect('index')
    return render(request, 'create_subfolder.html', {'folder': folder})

@login_required
def upload_file(request):
    if request.method == 'POST':
        file = request.FILES['file']
        File.objects.create(file=file, user=request.user)
        return redirect('index')
    return render(request, 'upload_file.html')